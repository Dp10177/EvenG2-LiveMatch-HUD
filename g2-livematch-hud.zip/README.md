# G2 LiveMatch HUD

## Setup

### Backend
npm install
node backend/server.js

### Frontend
Use any static server or Vite

### API Key
Replace YOUR_API_KEY in backend/sportsApi.js
