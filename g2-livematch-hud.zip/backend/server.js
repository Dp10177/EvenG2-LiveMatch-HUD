const WebSocket = require("ws");
const { getLiveMatches, getMatchData } = require("./sportsApi");

const wss = new WebSocket.Server({ port: 3000 });

let clients = [];

wss.on("connection", (ws) => {
  clients.push(ws);

  ws.on("message", (msg) => {
    const data = JSON.parse(msg);
    if (data.action === "subscribe") ws.matchId = data.matchId;
  });
});

setInterval(async () => {
  const matches = await getLiveMatches();

  clients.forEach(ws => {
    ws.send(JSON.stringify({ type: "matches", matches }));
  });

  for (const ws of clients) {
    if (ws.matchId) {
      const data = await getMatchData(ws.matchId);
      ws.send(JSON.stringify({ type: "update", matchId: ws.matchId, ...data }));
    }
  }
}, 1000);
