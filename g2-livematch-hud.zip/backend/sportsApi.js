const axios = require("axios");
const API_KEY = "YOUR_API_KEY";

async function getLiveMatches() {
  const res = await axios.get("https://api-football-v1.p.rapidapi.com/v3/fixtures?live=all", {
    headers: { "X-RapidAPI-Key": API_KEY }
  });

  return res.data.response.map(m => ({
    id: m.fixture.id,
    home: m.teams.home.name,
    away: m.teams.away.name
  }));
}

async function getMatchData(id) {
  const res = await axios.get(`https://api-football-v1.p.rapidapi.com/v3/fixtures?id=${id}`, {
    headers: { "X-RapidAPI-Key": API_KEY }
  });

  const m = res.data.response[0];

  return {
    home: m.teams.home.name,
    away: m.teams.away.name,
    score: m.goals,
    time: m.fixture.status.elapsed + "'",
    stats: m.statistics
  };
}

module.exports = { getLiveMatches, getMatchData };
