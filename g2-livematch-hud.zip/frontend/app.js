const socket = new WebSocket("ws://localhost:3000");
let currentMatch = null;

socket.onmessage = (event) => {
  const data = JSON.parse(event.data);

  if (data.type === "matches") renderMenu(data.matches);

  if (data.type === "update" && data.matchId === currentMatch) {
    updateScoreboard(data);
  }
};

function renderMenu(matches) {
  const menu = document.getElementById("menu");
  menu.innerHTML = "";

  matches.forEach(match => {
    const btn = document.createElement("button");
    btn.innerText = `${match.home} vs ${match.away}`;
    btn.onclick = () => selectMatch(match.id);
    menu.appendChild(btn);
  });
}

function selectMatch(id) {
  currentMatch = id;
  socket.send(JSON.stringify({ action: "subscribe", matchId: id }));

  document.getElementById("menu").classList.add("hidden");
  document.getElementById("scoreboard").classList.remove("hidden");
}

function updateScoreboard(data) {
  document.getElementById("teamA").innerText = data.home;
  document.getElementById("teamB").innerText = data.away;
  document.getElementById("score").innerText = `${data.score.home}-${data.score.away}`;
  document.getElementById("time").innerText = data.time;
}
