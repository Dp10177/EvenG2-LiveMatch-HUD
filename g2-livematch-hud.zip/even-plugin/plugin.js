import { display } from "even_hub_sdk";
display.openWebView("http://localhost:5173");
